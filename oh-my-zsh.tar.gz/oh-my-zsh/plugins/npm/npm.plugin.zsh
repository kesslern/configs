eval "$(npm completion 2>/dev/null)"

# Install and save to dependencies
alias npms="npm i -S "

# Install and save to dev-dependencies
alias npmd="npm i -D "
